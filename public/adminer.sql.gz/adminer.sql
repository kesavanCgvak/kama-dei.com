-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `rpamapping`;

DROP TABLE IF EXISTS `bot_type`;
CREATE TABLE `bot_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `show_order` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `bot_type` (`id`, `name`, `show_order`) VALUES
(1,	'Lexjoint',	1),
(2,	'KaaS',	2),
(3,	'Live Agent',	3),
(4,	'RPA 1 (Lex)',	4),
(9,	'RPA 2 (Microsoft)',	5);

DROP TABLE IF EXISTS `mapping_bot`;
CREATE TABLE `mapping_bot` (
  `bot_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bot_type_id` int(10) unsigned NOT NULL,
  `mappingName` varchar(250) NOT NULL,
  `bot_name` varchar(250) NOT NULL,
  `bot_alias` varchar(250) NOT NULL,
  `ownerId` int(10) unsigned NOT NULL,
  `bot_persona_id` int(10) unsigned DEFAULT NULL,
  `bot_personality_id` int(10) unsigned DEFAULT NULL,
  `bot_user_id` int(10) unsigned DEFAULT NULL,
  `portal_id` int(10) unsigned DEFAULT NULL,
  `structure_id` int(10) unsigned DEFAULT NULL,
  `publish_status` enum('Published','Unpublished') NOT NULL DEFAULT 'Unpublished',
  `user_id` int(10) unsigned NOT NULL,
  `last` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`bot_id`) USING BTREE,
  KEY `mapping_type_id` (`bot_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `mapping_bot` (`bot_id`, `bot_type_id`, `mappingName`, `bot_name`, `bot_alias`, `ownerId`, `bot_persona_id`, `bot_personality_id`, `bot_user_id`, `portal_id`, `structure_id`, `publish_status`, `user_id`, `last`) VALUES
(1,	4,	'Mapping data for Amazon Lex',	'rbcQuote',	'rbcQuoteAlias',	23,	NULL,	NULL,	NULL,	7,	2,	'Published',	512,	'2023-03-31 01:18:21'),
(2,	4,	'kamaCare',	'UTIbot',	'UTIbotAlias',	22,	NULL,	NULL,	NULL,	17,	2,	'Published',	570,	'2023-03-21 15:14:43'),
(3,	4,	'Lex Insurance Bot',	'rbcQuote',	'rbcQuoteAlias',	30,	NULL,	NULL,	NULL,	32,	2,	'Published',	4,	'2023-03-30 14:57:37'),
(7,	4,	'Sample for dental registration',	'rbcQuote',	'rbcQuoteAlias',	1,	NULL,	NULL,	NULL,	11,	2,	'Published',	4,	'2024-08-23 14:46:17'),
(6,	4,	'Lead capture bot',	'LeadCapture',	'LeadCaptureAlias',	1,	NULL,	NULL,	NULL,	11,	2,	'Unpublished',	4,	'2024-08-23 14:46:09'),
(10,	4,	'Sample for Scotiabank Quote',	'scotiaQuote',	'scotiaQuoteAlias',	6,	NULL,	NULL,	NULL,	46,	2,	'Published',	27832,	'2024-07-16 19:04:43');

DROP TABLE IF EXISTS `mapping_detail`;
CREATE TABLE `mapping_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mapping_header_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `val1` varchar(1000) DEFAULT NULL,
  `val2` varchar(1000) DEFAULT NULL,
  `val3` varchar(1000) DEFAULT NULL,
  `kr_id` int(10) unsigned NOT NULL,
  `tag` varchar(250) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `intentName` varchar(64) DEFAULT NULL,
  `apiVersion` varchar(16) DEFAULT NULL,
  `apiUrl` varchar(300) DEFAULT NULL,
  `organizationId` varchar(32) DEFAULT NULL,
  `deploymentId` varchar(32) DEFAULT NULL,
  `buttonId` varchar(32) DEFAULT NULL,
  `timeoutSwitch` int(1) unsigned DEFAULT NULL,
  `timeout` tinyint(3) unsigned DEFAULT NULL,
  `last` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`mapping_header_id`),
  KEY `kr_id` (`kr_id`),
  KEY `key1` (`kr_id`),
  KEY `kye0` (`mapping_header_id`,`kr_id`),
  KEY `parent_id_2` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `mapping_detail` (`id`, `mapping_header_id`, `parent_id`, `type_id`, `val1`, `val2`, `val3`, `kr_id`, `tag`, `user_id`, `intentName`, `apiVersion`, `apiUrl`, `organizationId`, `deploymentId`, `buttonId`, `timeoutSwitch`, `timeout`, `last`) VALUES
(1,	1,	0,	4,	NULL,	NULL,	NULL,	0,	NULL,	512,	'Intent - rpa',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-03-20 15:59:25'),
(2,	2,	0,	4,	NULL,	NULL,	NULL,	0,	NULL,	570,	'Intent - rpa',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-03-21 13:47:10'),
(3,	3,	0,	4,	NULL,	NULL,	NULL,	0,	NULL,	4,	'Intent - rpa',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-03-30 01:57:03'),
(7,	7,	0,	4,	NULL,	NULL,	NULL,	0,	NULL,	4,	'Intent - rpa',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-07-25 17:21:28'),
(6,	6,	0,	4,	NULL,	NULL,	NULL,	0,	NULL,	4,	'Intent - rpa',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2023-05-19 14:47:17'),
(10,	10,	0,	4,	NULL,	NULL,	NULL,	0,	NULL,	27832,	'Intent - rpa',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2024-06-10 16:39:00');

DROP TABLE IF EXISTS `mapping_kr`;
CREATE TABLE `mapping_kr` (
  `mapping_kr_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mapping_detail_id` int(10) unsigned NOT NULL,
  `kr_id` int(10) unsigned NOT NULL,
  `kr_order` int(10) unsigned NOT NULL,
  `handOffMessage` text CHARACTER SET utf8,
  `sampleUtterance` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`mapping_kr_id`),
  KEY `mapping_detail_id` (`mapping_detail_id`),
  KEY `kr_id` (`kr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `mapping_kr` (`mapping_kr_id`, `mapping_detail_id`, `kr_id`, `kr_order`, `handOffMessage`, `sampleUtterance`) VALUES
(1,	1,	3806,	0,	NULL,	'I need a term life insurance quote'),
(2,	1,	9776,	1,	NULL,	'I want to sell a house'),
(3,	2,	9759,	0,	NULL,	'I\'d like to do a UTI assessment'),
(5,	3,	9799,	0,	NULL,	'I need a term life insurance quote'),
(10,	6,	9881,	0,	NULL,	'please contact me'),
(7,	1,	0,	2,	NULL,	NULL),
(11,	7,	12506,	0,	NULL,	'I need a term life insurance quote'),
(17,	7,	12875,	1,	NULL,	NULL),
(14,	10,	12913,	0,	NULL,	'I need a term life insurance quote');

DROP TABLE IF EXISTS `pre_handoff`;
CREATE TABLE `pre_handoff` (
  `pre_handoff_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mapping_kr_id` bigint(20) unsigned NOT NULL,
  `lang_code` varchar(10) NOT NULL,
  `pre_handoff_message` text,
  PRIMARY KEY (`pre_handoff_message_id`),
  KEY `mapping_kr_id` (`mapping_kr_id`),
  KEY `lang_code` (`lang_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `pre_handoff` (`pre_handoff_message_id`, `mapping_kr_id`, `lang_code`, `pre_handoff_message`) VALUES
(1,	3,	'en',	'I\'m sorry to hear that you are experiencing this. We have an automated Bot that can help you decide whether you need to go see a Physician, or whether you can get a treatment directly from a Pharmacist.<br><br>Click the button if you wish to proceed with the assessment.'),
(2,	1,	'en',	'Yes, of course; we want to help you protect those that are important to you.<br><br> \nIf you like, I have an automated function available to assist with a life insurance quote. For your information, this function will ask for the age, gender, weight, height, smoking history, and amount of the insurance.<br><br>If you would like to proceed with this, please click the button below to proceed.'),
(3,	5,	'en',	'If you like, I have an automated function available to assist with a life insurance quote. For your information, this function will ask for the age, gender, weight, height, smoking history, and amount of the insurance.'),
(4,	2,	'en',	'Thanks! I have an automated function to provide recommendations on  purchasing a home. This bot will ask for the type of home, the location you are looking at, and your budget.'),
(6,	10,	'en',	'Thanks for your inquiry! You can follow the process below and I can gather your information for  a phone or email follow-up.'),
(7,	11,	'en',	'As an alternative to making an appointment with a live agent, you can use our automated term life insurance quotation by clicking button below.'),
(8,	14,	'en',	'Yes, of course; we want to help you protect those that are important to you. <br><br>\nIf you like, I have an automated function available to assist with a life insurance quote. For your information, this function will ask for the age, gender, weight, height, smoking history, and amount of the insurance.<br><br>\nIf you would like to proceed with this, please click the button below to proceed.'),
(9,	17,	'en',	'If you like, I have an automated available function to assist with a critical illness insurance quote. For your information, this function will ask for the age, gender, smoking history, weight, height, and amount of the insurance.\nIf you would like to proceed with this, please click the button below.');

DROP TABLE IF EXISTS `structure`;
CREATE TABLE `structure` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `bot_type_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bot_type_id` (`bot_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `structure` (`id`, `name`, `bot_type_id`) VALUES
(1,	'Intent/Slot',	2),
(2,	'Intent / Slot',	4),
(4,	'Intent/Slot',	9);

DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `structure_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `structure_id` (`structure_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `type` (`id`, `name`, `structure_id`, `parent_id`) VALUES
(1,	'Intent',	1,	0),
(2,	'Slot',	1,	1),
(3,	'Value',	1,	2),
(4,	'Intent - rpa',	2,	0),
(5,	'slot - rpa',	2,	4),
(6,	'value - rpa',	2,	5),
(7,	'Intent - rpa 2',	4,	0),
(8,	'Slot - rpa 2',	4,	7),
(9,	'value - rpa 2',	4,	8);

-- 2024-10-09 13:54:29
